//
//  Sudoku_alg.h
//  
//
//  Created by Paul Adeyemi on 08.11.13.
//
//

#ifndef _Sudoku_h
#define _Sudoku_h

int isAvailable(int[][],int,int,int);
int fillsudoku(int[][],int,int);

#endif
