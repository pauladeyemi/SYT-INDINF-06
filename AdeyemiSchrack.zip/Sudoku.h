//
//  Sudoku.h
//  
//
//  Created by Paul Adeyemi on 08.11.13.
//
//

#ifndef _Sudoku_h
#define _Sudoku_h

int filetoarray(void);
int ausgabe(void);
int raetsel1(void);
int raetsel2(void);

#endif
