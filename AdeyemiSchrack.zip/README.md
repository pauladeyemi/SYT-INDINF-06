SYT-INDINF-06
============

Sudoku
